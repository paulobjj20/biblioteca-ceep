// Importando o pacote mysql2
const mysql = require('mysql2');

// Criando a configuração da conexão
const conexao = mysql.createConnection({
  host: 'localhost',          // Onde o banco está rodando (geralmente localhost)
  user: 'root',               // Seu usuário do MySQL (o padrão costuma ser root)
  password: '123456', // A senha que você usa para entrar no Workbench
  database: 'discipulos_de_evandro'   // O nome do banco de dados (schema) que você criou
});

// Testando a conexão
conexao.connect((erro) => {
  if (erro) {
    console.error('Erro ao conectar ao banco de dados: ', erro);
    return;
  }
  console.log('Conectado ao banco de dados da biblioteca com sucesso!');
});

// Exportando a conexão para usar em outras partes do seu site
module.exports = conexao;