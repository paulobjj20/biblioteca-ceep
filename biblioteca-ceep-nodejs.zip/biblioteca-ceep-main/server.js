const express = require('express');
const cors = require('cors');
const conexao = require('./conexao'); // Puxa a conexão do seu conexao.js

const app = express();

app.use(cors());
app.use(express.json()); // Permite receber dados em formato JSON do front-end

// Rota para cadastrar (exemplo com livro)
app.post('/cadastrar-livro', (req, res) => {
  const { titulo, autor } = req.body; // Pega os dados vindos do HTML

  // Query SQL para inserir no banco
  const sql = 'INSERT INTO livros (titulo, autor) VALUES (?, ?)';

  conexao.query(sql, [titulo, autor], (erro, resultado) => {
    if (erro) {
      console.error('Erro ao salvar no banco:', erro);
      return res.status(500).json({ mensagem: 'Erro ao cadastrar.' });
    }
    res.json({ mensagem: 'Cadastrado no banco de dados com sucesso!', id: resultado.insertId });
  });
});

// Liga o servidor na porta 3000
app.listen(3000, () => {
  console.log('Servidor rodando em http://localhost:3000');
});